

export default function Rodape(){
    return(
        <footer>
           <div className="direitos"><p>Todos os direitos reservados</p></div>
            
            <img className="icones" src="/git.png"/>
            <img className="icones" src="/face.png"/>
            <img className="icones" src="/twitter.png"/>
            <img className="icones" src="/porto3.png"/>
            
      
            
            
        </footer>
    )
}