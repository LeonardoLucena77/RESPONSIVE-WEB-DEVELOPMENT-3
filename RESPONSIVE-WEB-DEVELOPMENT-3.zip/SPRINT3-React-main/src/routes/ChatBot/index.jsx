export default function ChatBot() {
    return(
        <main>
            
                <h1>ChatBot</h1>
                
                <img className="chatbot" src="/chatbot2.png" alt="Mensagem"/>
                <h3>O ChatBot será a primeira etapa para o início do processo de
                     solicitação de guincho. O segurado deverá enviar mensagens via Telegram informando seus dados básicos como Nome, CPF, RG e número de apólice, em seguida, ele será encaminhado para o GuinchoSeguro, onde deverá selecionar as características que mais se adequal ao seu veículo, para que elas possam ser analisadas antes do envio do guincho.</h3>

        </main>
    )
}
    