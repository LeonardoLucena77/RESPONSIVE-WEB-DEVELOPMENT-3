export default function GuinchoSeguro() {
    return(
        <main>
            <h1>Guincho Seguro</h1>
        </main>
    )
}