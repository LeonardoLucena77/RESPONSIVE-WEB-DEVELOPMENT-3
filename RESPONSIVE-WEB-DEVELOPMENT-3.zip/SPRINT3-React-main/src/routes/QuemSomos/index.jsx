export default function QuemSomos() {
    return(
        <main>
            <h1>Integrantes</h1>
            <div className="integrantes">
                <h4> Leonardo Camargo Lucena - 552537</h4>
                <h4>Ana Paula Nascimento Silva - 552513</h4>
                <h4>Nathan Nunes Calsonari - 552539</h4>
                <h4>Geovana Ribeiro Domingos - 99646</h4>
                <h4>Calina Thalya Santana da Silva - 552523</h4>
              

            </div>
            <h1 className="repositorio">Link Repositório:</h1>
            <a href="https://github.com/LeonardoCamargo77/SPRINT3-React.git">Repositório Sprint3</a>
        </main>
    )
}